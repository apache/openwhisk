class Greeter {
    func getMessage() -> String {
        return "Hello stranger!"
    }
}
