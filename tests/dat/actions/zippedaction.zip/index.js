function entryPoint(args) {
    var pq = require("prog-quote")();

    return pq.next().value;
}

exports.main = entryPoint;
