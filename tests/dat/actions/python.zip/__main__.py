from greet import greet

def niam(args):
    return greet(args)
